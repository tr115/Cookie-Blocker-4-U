allCookies = [];
safeCookies = [];

chrome.tabs.query({
}, function(tabs) {
	chrome.storage.local.get({savedDomains: []}, function (result) {
		var domains = [];
		domains = result.savedDomains;
		for (let i = 0, tab; tab = tabs[i]; i++) {	
			var domain = getDomain(tab);
			if(!domains.includes(domain)){
				domains.push(domain);
				
			}
		}		
		chrome.storage.local.set({savedDomains: domains}, function () {
		});
	
		chrome.cookies.getAll({}, function(cookies) {				
			filterSafeCookies(cookies, domains);
			for (let i = 0, cookie; cookie = cookies[i]; i++) {	

			
				allCookies.unshift(cookie);
		    }

        var noSafe = (safeCookies.length / allCookies.length) * 100;
        var noUnsafe = ((allCookies.length - safeCookies.length) / allCookies.length) * 100;

		

      

        var chart = new CanvasJS.Chart("chartContainer", {
            animationEnabled: true,
            
            data: [{
              type: "pie",
              startAngle: 270,
              yValueFormatString: "##0.00\"%\"",
              indexLabel: "{label} {y}",
              dataPoints: [
                {y: noSafe, label: "First-Party Cookies"},
                {y: noUnsafe, label: "Third-Party Cookies"}
              ]
            }]
          });
          chart.render();

		});	
	});
});
    
function filterSafeCookies(cookies, domains){
	for (let i = 0, cookie; cookie = cookies[i]; i++) {
		if (checkDomain(cookie.domain, domains)){
			addCookie(cookie);
		}
	}
}

function getDomain(url){	
	let domain = (new URL(url.url));
	domain = domain.hostname.replace('www.','');
	return domain;
}

function checkDomain(domain, domains){
	var regex = new RegExp(domains.join( "|" ), "i");  
	return regex.test(domain);
}

function addCookie(cookie) {
	safeCookies.unshift(cookie);
}

window.onload = function() {

	var helpButton = document.getElementById("helpButtonHTML");
	helpButton.onclick = function(){

		var modal1 = document.getElementById("helpContainer");
		modal1.style.display = "block";
	
	}

	//Exit Button For Details

	var exitButton = document.getElementById("exitButtonHTML");

	exitButton.onclick = function(){

		var modal = document.getElementById("helpContainer");
		modal.style.display = "none";
		
	};
		
}
