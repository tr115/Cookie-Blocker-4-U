function refresh(){
	chrome.tabs.query({
	}, function(tabs) {
		chrome.storage.local.get({savedDomains: [], autoDeleteCookie: false}, function (result) {
			var domains = [];
			domains = result.savedDomains;
			for (let i = 0, tab; tab = tabs[i]; i++) {	
				var domain = getDomain(tab);
				if(!domains.includes(domain)){
					domains.push(domain);
				}
			}	

		
			chrome.cookies.getAll({}, function(cookies) {			
				var unsafeCookies = [];	
				unsafeCookies = filterUnsafeCookies(cookies, domains);
				if(result.autoDeleteCookie){
					deleteCookieAuto(unsafeCookies);
				}
			});	
			
			chrome.storage.local.set({savedDomains: domains}, function () {
			});
		});
	});	
}

chrome.cookies.onChanged.addListener(function()
{
	refresh();
});

chrome.tabs.onActivated.addListener(function() {
	refresh();
  });

chrome.tabs.onUpdated.addListener(function() {
	refresh();
});

function getDomain(url){	
	let domain = (new URL(url.url));
	domain = domain.hostname.replace('www.','');
	return domain;
}
  

function checkDomain(domain, domains){
	var regex = new RegExp(domains.join( "|" ), "i"); 
	return regex.test(domain);
}


function deleteCookieAuto(unsafeCookies){
	for (var i = 0, cookie; cookie = unsafeCookies[i]; i++) {
		deleteCookie(i, cookie);
	}
}

function deleteCookie(i, cookie){

	const url = "http" + (cookie.secure ? "s" : "") + "://" + cookie.domain + cookie.path;
    chrome.cookies.remove({url:url, name:cookie.name, storeId:cookie.storeId}, function(){

	});

}

function filterUnsafeCookies(cookies, domains){
	unsafeLocalCookies = [];
	for (let i = 0, cookie; cookie = cookies[i]; i++) {
		if (!checkDomain(cookie.domain, domains)){
			unsafeLocalCookies.unshift(cookie);
		}
	}
	return unsafeLocalCookies;
}
 