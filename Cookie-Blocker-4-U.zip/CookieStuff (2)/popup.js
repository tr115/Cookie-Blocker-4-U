allCookies = [];
unsafeCookies = [];

chrome.tabs.query({
}, function(tabs) {
	chrome.storage.local.get({savedDomains: [], autoDeleteCookie: false}, function (result) {
		var domains = [];
		domains = result.savedDomains;
		for (let i = 0, tab; tab = tabs[i]; i++) {	
			var domain = getDomain(tab);
			if(!domains.includes(domain)){
				domains.push(domain);
			}
		}
		
		var autoDeleteCheckbox = document.getElementById("chkBox_AutoCookie");
		autoDeleteCheckbox.checked = result.autoDeleteCookie;

		chrome.storage.local.set({savedDomains: domains}, function () {
		});
	
		chrome.cookies.getAll({}, function(cookies) {				
			$("#ac-table-body tr").remove();
			filterUnsafeCookies(cookies, domains);
			for (let i = 0, cookie; cookie = cookies[i]; i++) {	
				
					allCookies.unshift(cookie);
			}
			updateRowIndex();
			clearAllCookiesFunc();
			autoDeleteCookiesFunc();
		});	
	});
});


function pushCookies(cookies){
	for (let cookie of cookies) {
		allCookies.unshift(cookie);
	  }
}

function getDomain(url){	
	let domain = (new URL(url.url));
	domain = domain.hostname.replace('www.','');
	return domain;
}


function addCookieToTable(cookie) {
	
    var table = document.getElementById("ac-table-body");
	var row = table.insertRow(0);
    var cell5 = row.insertCell(0);
	var cell2 = row.insertCell(1);
	var cell3 = row.insertCell(2);
	var cell4 = row.insertCell(3);
    
	
	cell2.innerHTML = cookie.domain;
	cell3.innerHTML = cookie.name;
	cell4.innerHTML = formatExpirationDateTime(cookie.expirationDate);
    cell5.innerHTML = 0;
    cell5.style = "display: none;"
	// Delete Button

	var deleteBtn = row.insertCell(4);
	deleteBtn.innerHTML = '<button class="waves-effect waves-light btn-small" id="deleteButton">Delete</button>';

	deleteBtn.onclick = function () {
		deleteFunction(row);	
	  };

	// Details Button

	var detailsBtn = row.insertCell(5);
	detailsBtn.innerHTML = '<button class="waves-effect waves-light btn-small" id="detailsButton">Details</button>';;

	detailsBtn.onclick = function(){
		var modal = document.getElementById("detailsDialogueContainer");
		modal.style.display = "block";
		detailsButton(row);
	}

	//Exit Button For Details

	var exitButton = document.getElementById("exitButtonHTMLDetails");

	exitButton.onclick = function(){

		var modal = document.getElementById("detailsDialogueContainer");
		modal.style.display = "none";
		
	};

	

}

 // AC Cookie Counter
 var acCookieCounter = window.setInterval(function(){
	var totalRowCount = $("#ac-table-id tr").length;
	var trueRowCountExcludingHeader = (totalRowCount - 1);
	var accounter = document.getElementById("AC-Table-Count");
	accounter.innerHTML = trueRowCountExcludingHeader;
  }, );

function deleteFunction(r) {
	var j = parseInt(r.cells[0].innerHTML);
	document.getElementById("ac-table-body").deleteRow(j);
	for (var i = 0, cookie; cookie = unsafeCookies[i]; i++) {
		if (i == j) {
			deleteCookie(i, cookie);
		}
	}
	unsafeCookies.splice(j,1);
    updateRowIndex();
}


function updateRowIndex(){
    var table = document.getElementById("ac-table-body");
    for (var i = 0; i< table.rows.length; i++){
        table.rows[i].cells[0].innerHTML = i;
    } 
}

function detailsButton(r){
	//get cookie of that row
	var i = parseInt(r.cells[0].innerHTML);
	var cookie = unsafeCookies[i]; // you have to make a list of all cookies in that table then index it

	var detailsDomain = $('#detailsDomainSpan');
	var detailsName = $('#detailsNameSpan');
	var detailsValue = $('#detailsValue');
	var detailsHO = $('#detailsHostOnly');
	var detailsSec = $('#detailsSecure');
	var detailsHTTP = $('#detailsHttpOnly');
	var detailsSess = $('#detailsSession');
	var detailsDate = $('#detailsExpirationDate');

	detailsDomain.html(cookie.domain);
	detailsName.html(cookie.name);
	detailsValue.html(cookie.value);
	detailsHO.html(cookie.hostOnly ? 'true' : 'false');
	detailsSec.html(cookie.secure ? 'true' : 'false');
	detailsHTTP.html(cookie.httpOnly ? 'true' : 'false');
	detailsSess.html(cookie.session ? 'true' : 'false');
	detailsDate.html(formatExpirationDateTime(cookie.expirationDate));

}


function deleteCookie(i, cookie){
	//Deletes Item From allCookies
	const url = "http" + (cookie.secure ? "s" : "") + "://" + cookie.domain + cookie.path;
    chrome.cookies.remove({url:url, name:cookie.name, storeId:cookie.storeId}, function(){

	});

}

function filterUnsafeCookies(cookies, domains){
	for (let i = 0, cookie; cookie = cookies[i]; i++) {
		if (!checkDomain(cookie.domain, domains)){
			addCookie(cookie);
		}
	}
}


function checkDomain(domain, domains){
	var regex = new RegExp(domains.join( "|" ), "i");  
	return regex.test(domain);
}

function addCookie(cookie) {
	addCookieToTable(cookie);
	unsafeCookies.unshift(cookie);
}


function clearAllCookiesFunc(){

	//Clear Cookies Button
	var clearAllCookiesBtn = document.getElementById("clear-all-cookies-button");

	clearAllCookiesBtn.onclick = function(){

		
		
		var table = document.getElementById("ac-table-body");

		myrows = [].slice.call(table.rows);
		


			for(i=0;i<myrows.length;i++){
				deleteFunction(myrows[i]);
			
			}


		}

}


function autoDeleteCookiesFunc(){

	//Clear Cookies Button
	var autoClearAllCookiesChk = document.getElementById("chkBox_AutoCookie");

	autoClearAllCookiesChk.onclick = function(){
		if(autoClearAllCookiesChk.checked == true){
			chrome.storage.local.set({autoDeleteCookie: true}, function () {
			});

			var table = document.getElementById("ac-table-body");
			myrows = [].slice.call(table.rows);
			for(i=0;i<myrows.length;i++){
				deleteFunction(myrows[i]);			
			}		
		}
		else{
			chrome.storage.local.set({autoDeleteCookie: false}, function () {
			});
		}
	}
}

//Formats Date and Time - Credit : UpWay2Late
function formatExpirationDateTime(expirationDate) {
	if (expirationDate == undefined) {
		return 'session';
	}
	var d = new Date(expirationDate*1000);
	var date = d.getDate();
	var month = d.getMonth() + 1;
	var year = d.getFullYear();
	var hours = d.getHours();
	var minutes = d.getMinutes();
	var seconds = d.getSeconds();
	if (minutes < 10) {
		minutes = '0' + minutes;
	}
	if (seconds < 10) {
		seconds = '0' + seconds;
	}
	return month + '/' + date + '/' + year + ' ' + hours + ':' + minutes + ':' + seconds;
}


window.onload = function() {

	var helpButton = document.getElementById("helpButtonHTML");
	helpButton.onclick = function(){

		var modal2 = document.getElementById("detailsDialogueContainer");
		modal2.style.display = "none";

		var modal1 = document.getElementById("helpContainer");
		modal1.style.display = "block";
	

		var tableID = document.getElementById("ac-table-id");
		tableID.style.display = "none";


		var otherexitButton = document.getElementById("exitButtonHTML");

		otherexitButton.onclick = function(){

			var modal = document.getElementById("detailsDialogueContainer");
			modal.style.display = "block";

			var modal1 = document.getElementById("helpContainer");
			modal1.style.display = "none";
			
			var tableID = document.getElementById("ac-table-id");
			tableID.style.display = "block";
		};

		
		
	}

	
}
